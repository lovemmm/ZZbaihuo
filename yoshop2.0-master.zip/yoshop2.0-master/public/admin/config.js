window.serverConfig = {
  // 系统名称
  APP_NAME: '萤火商城系统2.0',
  // 必填: api地址, 换成自己的域名即可
  // 例如: https://www.你的域名.com/index.php?s=/admin
  BASE_API: '../index.php?s=/admin',
  // 必填: store模块的入口地址
  // 例如: https://www.你的域名.com/store
  STORE_URL: '../store'
}
