<?php

namespace app\api\controller;

/**
 * 默认控制器
 * Class Index
 * @package app\api\controller
 */
class Index
{
    public function index()
    {
        echo '当前访问的index.php，请将index.html设为默认站点入口';
    }
}